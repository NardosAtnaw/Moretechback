<?php
// $connection = mysqli_connect('localhost','root','','yeshiwas');
$connection = mysqli_connect('localhost', 'yeshiwaseyasucom_admin', 'N=Zj=]8D!wp]', 'yeshiwaseyasucom_Blog');
if (!$connection) {
    echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}
